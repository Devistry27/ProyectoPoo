
package model;

public interface Reservable {
    void reservar();
}