package model;

public interface Renovable {

    void renovar();
}
