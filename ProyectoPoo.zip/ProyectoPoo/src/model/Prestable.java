package model;

public interface Prestable {
    void prestar();
}