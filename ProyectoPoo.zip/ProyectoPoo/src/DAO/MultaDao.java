// dao/MultaDAO.java
package DAO;

import model.Multa;
import java.util.*;

public class MultaDao{
    private final Map<Integer, Multa> tabla = new HashMap<>();
    private int nextId = 1;

    public void save(Multa multa) {
        try {
            var field = Multa.class.getDeclaredField("id");
            field.setAccessible(true);
            field.setInt(multa, nextId);
        } catch (Exception ignored) {}
        tabla.put(nextId, multa);
        nextId++;
    }

    public Multa findById(int id) {
        return tabla.get(id);
    }

    public List<Multa> findAll() {
        return new ArrayList<>(tabla.values());
    }

    public void update(Multa multa) {
        tabla.put(multa.getId(), multa);
    }

    public void delete(int id) {
        tabla.remove(id);
    }
}
